
      <div class="modal fade" id="previewForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog" role="document">
              <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title" id="myModalLabel1">Предварительный просмотр</h4>
                  </div>

                  <div class="modal-body" style = "text-align: center">

                      <img id = "preview_image" width = "70" src="#">
                      <br><br>
                      <b> Текст задачи: </b>
                      <p id = "preview_text">   </p>
                      <br>
                      <b> Имя пользователя: </b>
                      <p id = "preview_name">   </p>
                      <br>
                      <b> Email пользователя: </b>
                      <p id = "preview_email">   </p>

                      <div class="clearfix"></div>
                  </div>

                  <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                  </div>
              </div>
          </div>
      </div>

